import React, { useEffect, useState, useCallback } from 'react';
import { Download } from 'lucide-react';
import { apiRequest } from '../lib/api.ts';
import { formatInr, formatShortDate, formatUtcDateTime } from '../lib/format.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { EmptyState, Modal, SkeletonRows, StatusText } from '../components/Shell.tsx';

interface InvoiceRow {
  id: string;
  invoiceRef: string;
  customerRef: string;
  customerName: string;
  projectRef: string;
  projectName: string;
  title: string;
  totalPaise: number;
  verifiedPaidPaise: number;
  outstandingPaise: number;
  taxRegime: string;
  status: string;
  createdAt: string;
}

export function InvoicesPage() {
  const [list, setList] = useState<InvoiceRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiRequest<{ invoices: InvoiceRow[] }>('/invoices')
      .then((res) => setList(res.invoices))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const downloadPdf = async (id: string) => {
    try {
      const res = await apiRequest<{ pdfDownloadUrl: string }>(`/invoices/${id}`);
      const a = document.createElement('a');
      a.href = res.pdfDownloadUrl;
      a.download = '';
      a.click();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to fetch invoice download link.');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Invoices
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Authoritative billing invoices synced from Admin HQ with authenticated expiring PDF downloads.
        </p>
      </div>
      {error && (
        <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/20 rounded-lg px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}
      {loading ? (
        <SkeletonRows rows={5} />
      ) : list.length === 0 ? (
        <EmptyState
          title="No invoices issued yet"
          description="Create a project with an instalment schedule or create a payment request to generate an invoice."
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-950/40">
                  <th className="py-2.5 px-4 font-medium">Invoice Ref</th>
                  <th className="py-2.5 px-4 font-medium">Customer · Project</th>
                  <th className="py-2.5 px-4 font-medium">Tax Profile</th>
                  <th className="py-2.5 px-4 font-medium text-right">Total</th>
                  <th className="py-2.5 px-4 font-medium text-right">Verified Paid</th>
                  <th className="py-2.5 px-4 font-medium text-right">Balance</th>
                  <th className="py-2.5 px-4 font-medium">Status</th>
                  <th className="py-2.5 px-4 font-medium text-right">PDF</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {list.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-mono font-semibold">{inv.invoiceRef}</td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 dark:text-slate-100">
                        {inv.customerName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {inv.projectName} ({inv.projectRef})
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                      {inv.taxRegime}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right">
                      {formatInr(inv.totalPaise)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-emerald-700 dark:text-emerald-400">
                      {formatInr(inv.verifiedPaidPaise)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right font-medium">
                      {formatInr(inv.outstandingPaise)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusText status={inv.status} />
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => downloadPdf(inv.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                      >
                        <Download className="w-3 h-3" />
                        <span>PDF</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

interface ReceiptRow {
  id: string;
  receiptNumber: string;
  paymentRef: string;
  invoiceRef: string;
  projectName: string;
  customerName: string;
  customerRef: string;
  category: string;
  paidAmountPaise: number;
  verifiedUtr: string;
  issuedAt: string;
  pdfDownloadUrl: string;
}

export function ReceiptsPage() {
  const [list, setList] = useState<ReceiptRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiRequest<{ receipts: ReceiptRow[] }>('/receipts')
      .then((res) => setList(res.receipts))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Verified Payment Receipts
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Official Advance, Milestone, and Final payment receipts issued strictly after backend bank-credit verification.
        </p>
      </div>
      {error && (
        <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/20 rounded-lg px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}
      {loading ? (
        <SkeletonRows rows={5} />
      ) : list.length === 0 ? (
        <EmptyState
          title="No verified receipts yet"
          description="Receipts are never generated for unverified or customer-reported payments. Confirm a payment credit in Finance HQ to issue its receipt."
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-950/40">
                  <th className="py-2.5 px-4 font-medium">Receipt No</th>
                  <th className="py-2.5 px-4 font-medium">Payment ID · Category</th>
                  <th className="py-2.5 px-4 font-medium">Customer · Project</th>
                  <th className="py-2.5 px-4 font-medium">Verified UTR</th>
                  <th className="py-2.5 px-4 font-medium text-right">Amount</th>
                  <th className="py-2.5 px-4 font-medium text-right">Issued</th>
                  <th className="py-2.5 px-4 font-medium text-right">Download</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {list.map((rc) => (
                  <tr key={rc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-mono font-semibold text-emerald-700 dark:text-emerald-400">
                      {rc.receiptNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-mono text-slate-900 dark:text-slate-100">{rc.paymentRef}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {rc.category} · {rc.invoiceRef}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 dark:text-slate-100">
                        {rc.customerName}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {rc.projectName}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono">{rc.verifiedUtr}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right font-semibold">
                      {formatInr(rc.paidAmountPaise)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-slate-500 dark:text-slate-400">
                      {formatShortDate(rc.issuedAt)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <a
                        href={rc.pdfDownloadUrl}
                        download
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                      >
                        <Download className="w-3 h-3" />
                        <span>PDF</span>
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

interface DisputeRow {
  id: string;
  ticketRef: string;
  paymentRef: string;
  invoiceRef: string;
  customerName: string;
  customerRef: string;
  claimedUtr: string;
  claimedAmountPaise: number;
  expectedAmountPaise: number;
  approximateTime: string;
  explanation: string;
  supportingEvidenceNote: string;
  status: string;
  resolutionNote: string;
  createdAt: string;
}

export function DisputesPage() {
  const { hasAnyRole } = useAuth();
  const canResolve = hasAnyRole('SUPER_ADMIN', 'FINANCE_ADMIN');
  const [list, setList] = useState<DisputeRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [selected, setSelected] = useState<DisputeRow | null>(null);
  const [nextStatus, setNextStatus] = useState('UNDER_BANK_CHECK');
  const [resolutionNote, setResolutionNote] = useState('');
  const [matchedUtr, setMatchedUtr] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<{ disputes: DisputeRow[] }>('/disputes');
      setList(res.disputes);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load disputes.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    setSaving(true);
    setError(null);
    try {
      await apiRequest(`/disputes/${selected.id}`, {
        method: 'PATCH',
        body: {
          status: nextStatus,
          resolutionNote: resolutionNote.trim(),
          matchedBankUtr: matchedUtr.trim() || undefined,
        },
      });
      setNotice(`Dispute ticket ${selected.ticketRef} updated to ${nextStatus}. Customer notified.`);
      setSelected(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update dispute.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Missing Payments & Disputes
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Investigate customer-submitted missing payment claims. Customer screenshots and notes are supporting context only and never conclusive proof without a confirmed bank credit.
        </p>
      </div>

      {notice && (
        <div className="border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/20 rounded-lg px-4 py-3 text-xs text-emerald-800 dark:text-emerald-300">
          {notice}
        </div>
      )}
      {error && (
        <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/20 rounded-lg px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {loading ? (
        <SkeletonRows rows={4} />
      ) : list.length === 0 ? (
        <EmptyState
          title="No missing payment disputes"
          description="When a customer reports a missing payment from the Client Portal, a linked investigation ticket appears here for Finance HQ."
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-950/40">
                  <th className="py-2.5 px-4 font-medium">Ticket · Payment ID</th>
                  <th className="py-2.5 px-4 font-medium">Customer</th>
                  <th className="py-2.5 px-4 font-medium">Claimed UTR · Time</th>
                  <th className="py-2.5 px-4 font-medium text-right">Claimed Amount</th>
                  <th className="py-2.5 px-4 font-medium">Status</th>
                  {canResolve && <th className="py-2.5 px-4 font-medium text-right">Action</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {list.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4">
                      <div className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                        {d.ticketRef}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {d.paymentRef} · {d.invoiceRef}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium">{d.customerName}</div>
                      <div className="text-[11px] font-mono text-slate-500">{d.customerRef}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-mono text-slate-900 dark:text-slate-100">{d.claimedUtr}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {d.approximateTime} · {formatUtcDateTime(d.createdAt)}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right">
                      {formatInr(d.claimedAmountPaise)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusText status={d.status} />
                    </td>
                    {canResolve && (
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => {
                            setSelected(d);
                            setNextStatus('UNDER_BANK_CHECK');
                            setResolutionNote(d.resolutionNote || '');
                            setMatchedUtr(d.claimedUtr);
                          }}
                          className="px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          Manage
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        title={`Investigate Ticket ${selected?.ticketRef}`}
        subtitle={`Linked Payment ID: ${selected?.paymentRef}`}
      >
        <form onSubmit={handleUpdate} className="space-y-4">
          <div className="border border-slate-200 dark:border-slate-800 rounded-md p-3 text-xs space-y-1">
            <div>
              Claimed UTR: <span className="font-mono font-semibold">{selected?.claimedUtr}</span>
            </div>
            <div>
              Explanation: <span className="text-slate-600 dark:text-slate-300">{selected?.explanation || '—'}</span>
            </div>
            {selected?.supportingEvidenceNote && (
              <div>
                Supporting Info (non-conclusive):{' '}
                <span className="text-slate-600 dark:text-slate-300">
                  {selected.supportingEvidenceNote}
                </span>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Update Ticket Status</label>
            <select
              value={nextStatus}
              onChange={(e) => setNextStatus(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              <option value="ASSIGNED">Assign to Me</option>
              <option value="CLARIFICATION_REQUESTED">Request Clarification from Customer</option>
              <option value="UNDER_BANK_CHECK">Mark Under Bank Record Check</option>
              <option value="APPROVED_VERIFIED">Approve & Verify Bank Credit (Issues Receipt)</option>
              <option value="REJECTED">Reject Dispute with Reason</option>
              <option value="REOPENED">Reopen Investigation</option>
            </select>
          </div>

          {nextStatus === 'APPROVED_VERIFIED' && (
            <div>
              <label className="block text-xs font-medium mb-1">Verified Bank UTR</label>
              <input
                type="text"
                required
                value={matchedUtr}
                onChange={(e) => setMatchedUtr(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono uppercase rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-medium mb-1">Resolution / Customer Update Note</label>
            <textarea
              required
              rows={3}
              value={resolutionNote}
              onChange={(e) => setResolutionNote(e.target.value)}
              placeholder="Explain findings from bank statement check..."
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setSelected(null)}
              className="px-4 py-2 text-xs rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
            >
              {saving ? 'Updating...' : 'Save Ticket Update'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
