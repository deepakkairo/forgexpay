import React, { useEffect, useState, useCallback } from 'react';
import {
  ArrowRight,
  RefreshCw,
  TrendingUp,
  Wallet,
  ShieldCheck,
  AlertTriangle,
  Copy,
  Check,
  Landmark,
  Blocks,
  Smartphone,
} from 'lucide-react';
import { apiRequest } from '../lib/api.ts';
import { formatInr, formatUtcDateTime } from '../lib/format.ts';
import { NavSection, SkeletonRows, StatusText } from '../components/Shell.tsx';
import { useToast } from '../context/ToastContext.tsx';

interface OverviewResponse {
  metrics: {
    totalVerifiedCollectionsPaise: number;
    totalExpectedPaise: number;
    totalReportedUnverifiedPaise: number;
    outstandingBalancePaise: number;
    outstandingInvoicesCount: number;
    paymentsAwaitingVerificationCount: number;
    activeDisputesCount: number;
    reconciliationExceptionsCount: number;
    connectedApplicationsCount: number;
    apiTotalRequests: number;
    apiFailedRequests: number;
  };
  activeReceivingAccount: {
    accountCode: string;
    bankName: string;
    accountNumberMasked: string;
    upiId: string;
    manualCheckAttested: boolean;
  } | null;
  recentTransactions: Array<{
    id: string;
    paymentRef: string;
    customerRef: string;
    customerName: string;
    invoiceRef: string;
    category: string;
    expectedAmountPaise: number;
    verifiedAmountPaise: number | null;
    status: string;
    verifiedUtr: string | null;
    customerReportedUtr: string | null;
    createdAt: string;
  }>;
}

export function OverviewPage({ onNavigate }: { onNavigate: (s: NavSection) => void }) {
  const { showToast } = useToast();
  const [data, setData] = useState<OverviewResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copiedUpi, setCopiedUpi] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<OverviewResponse>('/overview');
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load dashboard metrics.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleCopyUpi = async (upiId: string) => {
    try {
      await navigator.clipboard.writeText(upiId);
      setCopiedUpi(true);
      showToast(`Copied ${upiId}`, 'success');
      window.setTimeout(() => setCopiedUpi(false), 1800);
    } catch {
      showToast('Unable to copy UPI ID.', 'error');
    }
  };

  if (loading && !data) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-72 bg-slate-200/80 dark:bg-slate-800 rounded-xl animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-32 rounded-2xl bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 p-5 animate-pulse"
            />
          ))}
        </div>
        <SkeletonRows rows={5} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="border border-rose-200 dark:border-rose-900/60 bg-white dark:bg-[#071630] rounded-2xl p-6 shadow-xs">
        <h2 className="text-base font-bold text-rose-700 dark:text-rose-400">
          Failed to Load Overview
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{error}</p>
        <button
          type="button"
          onClick={load}
          className="mt-4 px-4 py-2 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  const m = data!.metrics;
  const totalDenominator = Math.max(
    1,
    m.totalVerifiedCollectionsPaise + m.totalReportedUnverifiedPaise + m.outstandingBalancePaise
  );
  const verifiedPct = Math.round((m.totalVerifiedCollectionsPaise / totalDenominator) * 100);
  const reportedPct = Math.round((m.totalReportedUnverifiedPaise / totalDenominator) * 100);
  const outstandingPct = Math.max(0, 100 - verifiedPct - reportedPct);
  const hasFinancialActivity =
    m.totalVerifiedCollectionsPaise > 0 ||
    m.totalReportedUnverifiedPaise > 0 ||
    m.outstandingBalancePaise > 0;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#072146] dark:text-white">
            Financial Operations Overview
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Live database-backed collections separating expected dues, customer-reported claims, and verified bank credits.
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            load();
            showToast('Dashboard refreshed.', 'info');
          }}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#071630] text-[#072146] dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#0a1b38] transition-colors whitespace-nowrap shrink-0 shadow-xs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Receiving Account Status Bar */}
      {!data!.activeReceivingAccount ? (
        <div className="border border-amber-300/90 dark:border-amber-500/30 bg-amber-50/70 dark:bg-amber-500/10 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-start gap-3 max-w-2xl">
            <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
              <Landmark className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#072146] dark:text-white">
                Receiving UPI Account Not Configured
              </h2>
              <p className="mt-1 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                No active receiving bank account is configured. forgeXPay never ships with fictional bank details. Register and activate your authorised receiving UPI account before initiating customer payments.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('receiving-accounts')}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white transition-colors whitespace-nowrap shrink-0"
          >
            <span>Configure Receiving Account</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl px-5 py-4 flex flex-wrap items-center justify-between gap-4 shadow-xs">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-slate-600 dark:text-slate-400">
            <div className="w-8 h-8 rounded-xl bg-sky-50 dark:bg-sky-500/15 text-[#0d6efd] dark:text-[#25d0ff] flex items-center justify-center shrink-0">
              <Landmark className="w-4 h-4" />
            </div>
            <span className="font-semibold text-[#072146] dark:text-white">
              Active Receiving UPI
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono font-semibold text-[#0d6efd] dark:text-[#25d0ff]">
              {data!.activeReceivingAccount.upiId}
            </span>
            <button
              type="button"
              onClick={() => handleCopyUpi(data!.activeReceivingAccount!.upiId)}
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-500 hover:text-[#072146] dark:hover:text-white transition-colors"
              title="Copy receiving UPI ID"
            >
              {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            <span aria-hidden="true">·</span>
            <span>{data!.activeReceivingAccount.bankName}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{data!.activeReceivingAccount.accountNumberMasked}</span>
            <span aria-hidden="true">·</span>
            <span
              className={
                data!.activeReceivingAccount.manualCheckAttested
                  ? 'text-emerald-700 dark:text-emerald-400 font-semibold'
                  : 'text-amber-700 dark:text-amber-400 font-semibold'
              }
            >
              {data!.activeReceivingAccount.manualCheckAttested
                ? 'Manual Check Attested'
                : 'Manual Check Pending'}
            </span>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('receiving-accounts')}
            className="text-xs font-semibold text-[#0d6efd] dark:text-[#25d0ff] hover:underline whitespace-nowrap shrink-0"
          >
            Manage Accounts →
          </button>
        </div>
      )}

      {/* 4 Elevated KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="rounded-2xl bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Verified Collections
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
            {formatInr(m.totalVerifiedCollectionsPaise)}
          </div>
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
            Ledger-backed confirmed credits
          </p>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Outstanding Balance Due
            </span>
            <div className="w-8 h-8 rounded-xl bg-sky-50 dark:bg-sky-500/15 text-[#0d6efd] dark:text-[#25d0ff] flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-[#072146] dark:text-white">
            {formatInr(m.outstandingBalancePaise)}
          </div>
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {m.outstandingInvoicesCount} open invoices · {formatInr(m.totalExpectedPaise)} billed
          </p>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Awaiting Verification
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-700 dark:text-amber-400">
            {m.paymentsAwaitingVerificationCount}
          </div>
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {formatInr(m.totalReportedUnverifiedPaise)} reported (unverified)
          </p>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Exceptions &amp; Disputes
            </span>
            <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-[#072146] dark:text-sky-300 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-[#072146] dark:text-white">
            {m.activeDisputesCount + m.reconciliationExceptionsCount}
          </div>
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {m.activeDisputesCount} disputes · {m.reconciliationExceptionsCount} recon exceptions
          </p>
        </div>
      </div>

      {/* Real-Data Collection Progress & Quick Navigation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-[#072146] dark:text-white">
              Collection Verification Split
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Live ledger distribution across billed obligations
            </p>
          </div>

          <div className="my-5 space-y-3">
            <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-[#0a1b38] overflow-hidden flex">
              {hasFinancialActivity ? (
                <>
                  <div
                    className="h-full bg-emerald-500 transition-all duration-300"
                    style={{ width: `${verifiedPct}%` }}
                  />
                  <div
                    className="h-full bg-amber-400 transition-all duration-300"
                    style={{ width: `${reportedPct}%` }}
                  />
                  <div
                    className="h-full bg-[#0d6efd]/80 transition-all duration-300"
                    style={{ width: `${outstandingPct}%` }}
                  />
                </>
              ) : (
                <div className="h-full w-full bg-slate-200/70 dark:bg-slate-800" />
              )}
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-300 font-medium">
                  Verified Bank Credits
                </span>
                <span className="font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                  {formatInr(m.totalVerifiedCollectionsPaise)} ({hasFinancialActivity ? verifiedPct : 0}%)
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-300 font-medium">
                  Customer-Reported (Unverified)
                </span>
                <span className="font-mono tabular-nums font-semibold text-amber-700 dark:text-amber-400">
                  {formatInr(m.totalReportedUnverifiedPaise)} ({hasFinancialActivity ? reportedPct : 0}%)
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-300 font-medium">
                  Remaining Outstanding
                </span>
                <span className="font-mono tabular-nums font-semibold text-[#072146] dark:text-white">
                  {formatInr(m.outstandingBalancePaise)} ({hasFinancialActivity ? outstandingPct : 0}%)
                </span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-500 dark:text-slate-400">
              Only verified credits move balances
            </span>
            <button
              type="button"
              onClick={() => onNavigate('payment-requests')}
              className="font-semibold text-[#0d6efd] dark:text-[#25d0ff] hover:underline"
            >
              Payment Requests →
            </button>
          </div>
        </div>

        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button
            type="button"
            onClick={() => onNavigate('pending-verification')}
            className="text-left rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] p-5 hover:border-[#0d6efd]/50 dark:hover:border-[#00b8ff]/50 transition-colors shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-sky-50 dark:bg-sky-500/15 text-[#0d6efd] dark:text-[#25d0ff] flex items-center justify-center mb-3">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <span className="text-sm font-bold text-[#072146] dark:text-white">
                Verification Queue
              </span>
              <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Verify reported transfers against your banking app or import CSV statements.
              </p>
            </div>
            <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-[#0d6efd] dark:text-[#25d0ff]">
              <span>Open Queue</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('connected-apps')}
            className="text-left rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] p-5 hover:border-[#0d6efd]/50 dark:hover:border-[#00b8ff]/50 transition-colors shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-sky-50 dark:bg-sky-500/15 text-[#0d6efd] dark:text-[#25d0ff] flex items-center justify-center mb-3">
                <Blocks className="w-4 h-4" />
              </div>
              <span className="text-sm font-bold text-[#072146] dark:text-white">
                Connected Apps
              </span>
              <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums leading-relaxed">
                {m.connectedApplicationsCount} active · {m.apiTotalRequests} requests · {m.apiFailedRequests} denied
              </p>
            </div>
            <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-[#0d6efd] dark:text-[#25d0ff]">
              <span>Manage APIs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('client-portal')}
            className="text-left rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] p-5 hover:border-[#0d6efd]/50 dark:hover:border-[#00b8ff]/50 transition-colors shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="w-9 h-9 rounded-xl bg-sky-50 dark:bg-sky-500/15 text-[#0d6efd] dark:text-[#25d0ff] flex items-center justify-center mb-3">
                <Smartphone className="w-4 h-4" />
              </div>
              <span className="text-sm font-bold text-[#072146] dark:text-white">
                Client Portal
              </span>
              <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Initiate unique Payment IDs, display UPI QR codes, and download receipts.
              </p>
            </div>
            <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-[#0d6efd] dark:text-[#25d0ff]">
              <span>Open Portal</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </button>
        </div>
      </div>

      {/* Recent Payment Attempts Table */}
      <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-[#072146] dark:text-white">
              Recent Payment Attempts
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Latest unique FXPAY-* attempts with bank UTR references
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('transactions')}
            className="text-xs font-semibold text-[#0d6efd] dark:text-[#25d0ff] hover:underline inline-flex items-center gap-1 whitespace-nowrap"
          >
            <span>View all</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {data!.recentTransactions.length === 0 ? (
          <div className="px-5 py-12 text-center">
            <p className="text-sm font-bold text-[#072146] dark:text-white">
              No payment attempts recorded yet
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
              Configure a receiving UPI account, register a customer &amp; project, then initiate a payment attempt.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 bg-slate-50/70 dark:bg-[#0a1b38]/60">
                  <th className="py-3 px-5 font-semibold">Payment ID</th>
                  <th className="py-3 px-4 font-semibold">Customer · Invoice</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold text-right">Expected</th>
                  <th className="py-3 px-4 font-semibold">Bank UTR</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-5 font-semibold text-right">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {data!.recentTransactions.map((tx) => (
                  <tr
                    key={tx.id}
                    onClick={() => onNavigate('transactions')}
                    className="hover:bg-slate-50/90 dark:hover:bg-slate-800/40 cursor-pointer transition-colors"
                  >
                    <td className="py-3.5 px-5 font-mono font-semibold text-[#0d6efd] dark:text-[#25d0ff] whitespace-nowrap">
                      {tx.paymentRef}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-[#072146] dark:text-white">
                        {tx.customerName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {tx.customerRef} · {tx.invoiceRef}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">{tx.category}</td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-semibold text-right text-[#072146] dark:text-white">
                      {formatInr(tx.expectedAmountPaise)}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-600 dark:text-slate-300">
                      {tx.verifiedUtr || tx.customerReportedUtr || '—'}
                    </td>
                    <td className="py-3.5 px-4">
                      <StatusText status={tx.status} />
                    </td>
                    <td className="py-3.5 px-5 font-mono tabular-nums text-right text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {formatUtcDateTime(tx.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
