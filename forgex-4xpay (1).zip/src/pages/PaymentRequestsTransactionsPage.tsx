import React, { useEffect, useState, useCallback } from 'react';
import { Plus, QrCode, Copy, Check, Download, ExternalLink, Search, X } from 'lucide-react';
import { apiRequest, createIdempotencyKey } from '../lib/api.ts';
import { formatInr, formatUtcDateTime, rupeesInputToPaise } from '../lib/format.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { EmptyState, Modal, SkeletonRows, StatusText } from '../components/Shell.tsx';
import { BrandLogo } from '../components/BrandLogo.tsx';

export interface CheckoutInfo {
  attemptId: string;
  paymentRef: string;
  expectedAmountPaise: number;
  currency: string;
  receivingUpiId: string;
  payeeName: string;
  upiUri: string;
  qrDataUrl: string;
  expiresAt: string;
  notice: string;
}

export function UpiCheckoutModal({
  checkout,
  onClose,
  onReported,
}: {
  checkout: CheckoutInfo | null;
  onClose: () => void;
  onReported: () => void;
}) {
  const { showToast } = useToast();
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [showReportForm, setShowReportForm] = useState(false);
  const [utr, setUtr] = useState('');
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [resultMsg, setResultMsg] = useState<string | null>(null);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  if (!checkout) return null;

  const copyUpi = async () => {
    try {
      await navigator.clipboard.writeText(checkout.receivingUpiId);
      setCopiedUpi(true);
      showToast('Receiving UPI ID copied!', 'success');
      window.setTimeout(() => setCopiedUpi(false), 1800);
    } catch {
      showToast('Unable to copy UPI ID.', 'error');
    }
  };

  const downloadQr = () => {
    const a = document.createElement('a');
    a.href = checkout.qrDataUrl;
    a.download = `${checkout.paymentRef}-UPI-QR.png`;
    a.click();
    showToast('UPI QR image downloaded.', 'info');
  };

  const submitReport = async (outcome: 'PAID' | 'FAILED') => {
    setSubmitting(true);
    setErrMsg(null);
    setResultMsg(null);
    try {
      const res = await apiRequest<{ message: string }>(
        `/payments/${checkout.paymentRef}/report`,
        {
          method: 'POST',
          body: {
            outcome,
            utrReference: utr.trim(),
            reportedAmountPaise: checkout.expectedAmountPaise,
            note: note.trim(),
          },
        }
      );
      setResultMsg(res.message);
      setShowReportForm(false);
      showToast(
        outcome === 'PAID'
          ? 'Payment report submitted for Finance verification.'
          : 'Transfer failure recorded.',
        outcome === 'PAID' ? 'success' : 'warning'
      );
      onReported();
    } catch (err) {
      setErrMsg(err instanceof Error ? err.message : 'Unable to submit payment report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-2xl bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 rounded-2xl shadow-2xl my-8 overflow-hidden fade-view">
        {/* Branded Forge Navy Checkout Header */}
        <div className="bg-[#072146] px-6 py-4 text-white flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <BrandLogo size="sm" onDarkSurface />
            <div className="min-w-0">
              <div className="text-[11px] font-mono text-sky-300 truncate">{checkout.paymentRef}</div>
              <h2 className="text-sm font-bold text-white truncate">UPI Payment Checkout</h2>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <div className="text-right">
              <div className="text-[10px] text-sky-200/80">Expected</div>
              <div className="font-mono tabular-nums font-bold text-base text-white">
                {formatInr(checkout.expectedAmountPaise)}
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close checkout"
              className="p-1.5 rounded-xl text-sky-200 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[78vh] overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* QR Column */}
            <div className="flex flex-col items-center justify-center border border-slate-200/90 dark:border-slate-800 rounded-2xl p-5 bg-slate-50/70 dark:bg-[#0a1b38]">
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Scan with PhonePe, GPay, Paytm, or BHIM
              </div>
              <div className="mt-3.5 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
                <img
                  src={checkout.qrDataUrl}
                  alt={`UPI QR code for ${checkout.paymentRef}`}
                  className="w-52 h-52 object-contain"
                />
              </div>
              <div className="mt-3 text-[11px] font-mono text-slate-500 dark:text-slate-400 text-center">
                Valid until {formatUtcDateTime(checkout.expiresAt)}
              </div>
              <button
                type="button"
                onClick={downloadQr}
                className="mt-3 inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#071630] text-[#072146] dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download QR PNG</span>
              </button>
            </div>

            {/* Instructions & Actions Column */}
            <div className="space-y-4">
              <div className="space-y-2.5 text-xs">
                <div>
                  <div className="text-slate-500 dark:text-slate-400">Unique Payment ID</div>
                  <div className="font-mono font-bold text-sm text-[#0d6efd] dark:text-[#25d0ff]">
                    {checkout.paymentRef}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 dark:text-slate-400">Payee Name</div>
                  <div className="font-semibold text-[#072146] dark:text-white">
                    {checkout.payeeName}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 dark:text-slate-400">Receiving UPI ID</div>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="font-mono font-medium text-[#072146] dark:text-white">
                      {checkout.receivingUpiId}
                    </span>
                    <button
                      type="button"
                      onClick={copyUpi}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      {copiedUpi ? (
                        <Check className="w-3 h-3 text-emerald-500" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      <span>{copiedUpi ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <a
                  href={checkout.upiUri}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Pay via Installed UPI App</span>
                </a>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Actual funds transfer strictly through your UPI banking network. Finance verifies credit before issuing an official receipt. forgeXPay never asks for your UPI PIN.
                </p>
              </div>

              {resultMsg && (
                <div className="border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50/70 dark:bg-emerald-500/10 rounded-xl p-3 text-xs text-emerald-800 dark:text-emerald-300">
                  {resultMsg}
                </div>
              )}
              {errMsg && (
                <div className="border border-rose-200 dark:border-rose-500/30 bg-rose-50/70 dark:bg-rose-500/10 rounded-xl p-3 text-xs text-rose-700 dark:text-rose-300">
                  {errMsg}
                </div>
              )}

              {!resultMsg && !showReportForm && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={() => setShowReportForm(true)}
                    className="w-full px-4 py-2.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/80 dark:bg-[#0a1b38] hover:bg-slate-100 dark:hover:bg-[#0f2448] text-[#072146] dark:text-white transition-colors"
                  >
                    Report Payment Already Made
                  </button>
                  <button
                    type="button"
                    onClick={() => submitReport('FAILED')}
                    disabled={submitting}
                    className="w-full px-4 py-2 text-xs font-medium rounded-xl text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition-colors"
                  >
                    Report UPI Transfer Failed
                  </button>
                </div>
              )}

              {showReportForm && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      UPI Transaction Reference / UTR (12-digit preferred)
                    </label>
                    <input
                      type="text"
                      value={utr}
                      onChange={(e) => setUtr(e.target.value)}
                      placeholder="e.g. 432198765432"
                      className="forge-input w-full px-3.5 py-2 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0a1b38]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Optional Note
                    </label>
                    <input
                      type="text"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="Paid via PhonePe / GPay"
                      className="forge-input w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0a1b38]"
                    />
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowReportForm(false)}
                      className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      disabled={submitting}
                      onClick={() => submitReport('PAID')}
                      className="px-4 py-2 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white transition-colors"
                    >
                      {submitting ? 'Submitting...' : 'Submit for Verification'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface PaymentRequestItem {
  id: string;
  requestRef: string;
  invoiceRef: string;
  projectRef: string;
  projectName: string;
  customerRef: string;
  customerName: string;
  category: string;
  title: string;
  amountDuePaise: number;
  amountVerifiedPaise: number;
  remainingDuePaise: number;
  status: string;
  revisionNumber: number;
  createdAt: string;
}

interface ProjectOption {
  id: string;
  projectRef: string;
  name: string;
  customerName: string;
}

export function PaymentRequestsPage() {
  const { hasAnyRole } = useAuth();
  const { showToast } = useToast();
  const canCreate = hasAnyRole('SUPER_ADMIN', 'ADMIN_HQ');
  const [requests, setRequests] = useState<PaymentRequestItem[]>([]);
  const [projects, setProjects] = useState<ProjectOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({
    projectId: '',
    category: 'ADVANCE' as 'ADVANCE' | 'MILESTONE' | 'FINAL',
    title: 'Project Advance Payment',
    amountRupees: '5000',
  });
  const [submitting, setSubmitting] = useState(false);
  const [checkout, setCheckout] = useState<CheckoutInfo | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [reqRes, projRes] = await Promise.all([
        apiRequest<{ paymentRequests: PaymentRequestItem[] }>('/payment-requests'),
        apiRequest<{ projects: ProjectOption[] }>('/projects'),
      ]);
      setRequests(reqRes.paymentRequests);
      setProjects(projRes.projects);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load payment requests.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const amountDuePaise = rupeesInputToPaise(form.amountRupees);
      const res = await apiRequest<{ paymentRequest: { requestRef: string } }>('/payment-requests', {
        method: 'POST',
        body: {
          projectId: form.projectId,
          category: form.category,
          title: form.title,
          amountDuePaise,
        },
      });
      showToast(`Payment Request ${res.paymentRequest.requestRef} created.`, 'success');
      setCreateOpen(false);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create payment request.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleInitiateUpi = async (reqItem: PaymentRequestItem) => {
    setError(null);
    try {
      const res = await apiRequest<{
        attempt: { id: string };
        checkout: Omit<CheckoutInfo, 'attemptId'>;
      }>(`/payment-requests/${reqItem.id}/attempts`, {
        method: 'POST',
        headers: { 'Idempotency-Key': createIdempotencyKey('req') },
        body: {},
      });
      setCheckout({ ...res.checkout, attemptId: res.attempt.id });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to generate UPI payment attempt.');
    }
  };

  const handleCancel = async (reqItem: PaymentRequestItem) => {
    setError(null);
    try {
      await apiRequest(`/payment-requests/${reqItem.id}`, {
        method: 'PATCH',
        body: { action: 'CANCEL', reason: 'Cancelled by operator prior to verification' },
      });
      showToast(`Payment Request ${reqItem.requestRef} cancelled.`, 'warning');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to cancel request.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#072146] dark:text-white">
            Payment Requests
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Authorised instalment requests (FXREQ-*). Every deliberate Pay Now action mints a unique Payment ID (FXPAY-*).
          </p>
        </div>
        {canCreate && (
          <button
            type="button"
            disabled={projects.length === 0}
            onClick={() => {
              setForm((f) => ({ ...f, projectId: projects[0]?.id || '' }));
              setCreateOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white disabled:opacity-40 whitespace-nowrap transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Payment Request</span>
          </button>
        )}
      </div>

      {error && (
        <div className="border border-rose-200 dark:border-rose-500/30 bg-rose-50/70 dark:bg-rose-500/10 rounded-xl px-4 py-3 text-xs text-rose-700 dark:text-rose-300">
          {error}
        </div>
      )}

      {loading ? (
        <SkeletonRows rows={5} />
      ) : requests.length === 0 ? (
        <EmptyState
          title="No payment requests yet"
          description="Create a customer and project schedule first, or issue a standalone payment request for an existing project."
        />
      ) : (
        <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 bg-slate-50/70 dark:bg-[#0a1b38]/60">
                  <th className="py-3 px-5 font-semibold">Request ID</th>
                  <th className="py-3 px-4 font-semibold">Customer · Project</th>
                  <th className="py-3 px-4 font-semibold">Instalment</th>
                  <th className="py-3 px-4 font-semibold text-right">Due</th>
                  <th className="py-3 px-4 font-semibold text-right">Verified</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-5 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {requests.map((r) => (
                  <tr
                    key={r.id}
                    className="hover:bg-slate-50/90 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-5 font-mono font-semibold text-[#0d6efd] dark:text-[#25d0ff] whitespace-nowrap">
                      {r.requestRef}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-[#072146] dark:text-white">
                        {r.customerName} · {r.projectName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {r.invoiceRef} · Rev {r.revisionNumber}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-[#072146] dark:text-white">{r.title}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {r.category}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-semibold text-right">
                      {formatInr(r.amountDuePaise)}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-semibold text-right text-emerald-700 dark:text-emerald-400">
                      {formatInr(r.amountVerifiedPaise)}
                    </td>
                    <td className="py-3.5 px-4">
                      <StatusText status={r.status} />
                    </td>
                    <td className="py-3.5 px-5 text-right whitespace-nowrap space-x-2">
                      {r.status !== 'PAID' && r.status !== 'CANCELLED' && (
                        <>
                          <button
                            type="button"
                            onClick={() => handleInitiateUpi(r)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white transition-colors"
                          >
                            <QrCode className="w-3.5 h-3.5" />
                            <span>Generate UPI QR</span>
                          </button>
                          {canCreate && r.amountVerifiedPaise === 0 && (
                            <button
                              type="button"
                              onClick={() => handleCancel(r)}
                              className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 transition-colors"
                            >
                              Cancel
                            </button>
                          )}
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Create Payment Request"
        subtitle="Creates an authoritative FXREQ-* obligation backed by an invoice record."
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Project
            </label>
            <select
              required
              value={form.projectId}
              onChange={(e) => setForm({ ...form, projectId: e.target.value })}
              className="forge-input w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0a1b38]"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.projectRef} — {p.name} ({p.customerName})
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={form.category}
                onChange={(e) =>
                  setForm({ ...form, category: e.target.value as 'ADVANCE' | 'MILESTONE' | 'FINAL' })
                }
                className="forge-input w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0a1b38]"
              >
                <option value="ADVANCE">Advance</option>
                <option value="MILESTONE">Milestone</option>
                <option value="FINAL">Final</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Amount Due (INR)
              </label>
              <input
                type="text"
                required
                value={form.amountRupees}
                onChange={(e) => setForm({ ...form, amountRupees: e.target.value })}
                className="forge-input w-full px-3.5 py-2.5 text-sm font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0a1b38]"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Title / Description
            </label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="forge-input w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0a1b38]"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="px-4 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white transition-colors"
            >
              {submitting ? 'Creating...' : 'Create Request'}
            </button>
          </div>
        </form>
      </Modal>

      <UpiCheckoutModal
        checkout={checkout}
        onClose={() => setCheckout(null)}
        onReported={load}
      />
    </div>
  );
}

interface TransactionRow {
  id: string;
  paymentRef: string;
  requestRef: string;
  invoiceRef: string;
  projectRef: string;
  projectName: string;
  customerRef: string;
  customerName: string;
  category: string;
  receivingUpiSnapshot: string;
  expectedAmountPaise: number;
  reportedAmountPaise: number | null;
  verifiedAmountPaise: number | null;
  status: string;
  customerReportedUtr: string | null;
  verifiedUtr: string | null;
  createdAt: string;
  verifiedAt: string | null;
}

export function TransactionsPage() {
  const [rows, setRows] = useState<TransactionRow[]>([]);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<{ transactions: TransactionRow[] }>(
        `/transactions?status=${encodeURIComponent(statusFilter)}`
      );
      setRows(res.transactions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load transactions.');
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = rows.filter((r) => {
    if (!query.trim()) return true;
    const q = query.trim().toLowerCase();
    return (
      r.paymentRef.toLowerCase().includes(q) ||
      r.customerName.toLowerCase().includes(q) ||
      r.invoiceRef.toLowerCase().includes(q) ||
      (r.verifiedUtr || '').toLowerCase().includes(q) ||
      (r.customerReportedUtr || '').toLowerCase().includes(q)
    );
  });

  const filterOptions = [
    'ALL',
    'AWAITING_PAYMENT',
    'VERIFICATION_PENDING',
    'REVIEW_REQUIRED',
    'VERIFIED',
    'DISPUTED',
    'FAILED_REPORTED',
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-[#072146] dark:text-white">
          Transactions Ledger
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Complete immutable history of payment attempts with independent forgeXPay Payment IDs and bank UTR references.
        </p>
      </div>

      {/* Filters & Live Search */}
      <div className="rounded-2xl bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-[#0a1b38] border border-slate-200/70 dark:border-slate-800 rounded-xl">
          {filterOptions.map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-white dark:bg-[#071630] text-[#0d6efd] dark:text-[#25d0ff] shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-[#072146] dark:hover:text-white'
              }`}
            >
              {st === 'ALL' ? 'All' : st.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search Payment ID, UTR, customer..."
            className="forge-input w-full pl-10 pr-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0a1b38] text-[#072146] dark:text-white"
          />
        </div>
      </div>

      {error && (
        <div className="border border-rose-200 dark:border-rose-500/30 bg-rose-50/70 dark:bg-rose-500/10 rounded-xl px-4 py-3 text-xs text-rose-700 dark:text-rose-300">
          {error}
        </div>
      )}

      {loading ? (
        <SkeletonRows rows={6} />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No matching transactions"
          description="No payment attempts match the selected status filter and search query."
        />
      ) : (
        <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 bg-slate-50/70 dark:bg-[#0a1b38]/60">
                  <th className="py-3 px-5 font-semibold">Payment ID · Request</th>
                  <th className="py-3 px-4 font-semibold">Customer · Project</th>
                  <th className="py-3 px-4 font-semibold">Receiving UPI</th>
                  <th className="py-3 px-4 font-semibold text-right">Expected</th>
                  <th className="py-3 px-4 font-semibold text-right">Verified</th>
                  <th className="py-3 px-4 font-semibold">Bank UTR</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-5 font-semibold text-right">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {filtered.map((tx) => (
                  <tr
                    key={tx.id}
                    className="hover:bg-slate-50/90 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-5 whitespace-nowrap">
                      <div className="font-mono font-semibold text-[#0d6efd] dark:text-[#25d0ff]">
                        {tx.paymentRef}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {tx.requestRef} · {tx.category}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-[#072146] dark:text-white">
                        {tx.customerName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {tx.projectName} · {tx.invoiceRef}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-600 dark:text-slate-300">
                      {tx.receivingUpiSnapshot}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-semibold text-right">
                      {formatInr(tx.expectedAmountPaise)}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-semibold text-right text-emerald-700 dark:text-emerald-400">
                      {tx.verifiedAmountPaise ? formatInr(tx.verifiedAmountPaise) : '—'}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-700 dark:text-slate-300">
                      {tx.verifiedUtr ? (
                        <span className="text-emerald-700 dark:text-emerald-400">
                          {tx.verifiedUtr}
                        </span>
                      ) : tx.customerReportedUtr ? (
                        <span className="text-amber-700 dark:text-amber-400">
                          {tx.customerReportedUtr} (claimed)
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <StatusText status={tx.status} />
                    </td>
                    <td className="py-3.5 px-5 font-mono tabular-nums text-right text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {formatUtcDateTime(tx.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
