import React, { useEffect, useState, useCallback } from 'react';
import { Plus, FolderPlus } from 'lucide-react';
import { apiRequest } from '../lib/api.ts';
import { formatInr, rupeesInputToPaise } from '../lib/format.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { EmptyState, Modal, SkeletonRows, StatusText } from '../components/Shell.tsx';

interface CustomerRow {
  id: string;
  customerRef: string;
  name: string;
  email: string;
  phone: string;
  companyName: string;
  projectCount: number;
  totalContractPaise: number;
  verifiedPaidPaise: number;
  outstandingPaise: number;
}

interface ProjectRow {
  id: string;
  projectRef: string;
  customerId: string;
  customerRef: string;
  customerName: string;
  name: string;
  totalContractPaise: number;
  verifiedPaidPaise: number;
  outstandingPaise: number;
  progressPercent: number;
  status: string;
}

export function CustomersProjectsPage() {
  const { hasAnyRole } = useAuth();
  const canCreate = hasAnyRole('SUPER_ADMIN', 'ADMIN_HQ');
  const [tab, setTab] = useState<'customers' | 'projects'>('customers');
  const [customersList, setCustomersList] = useState<CustomerRow[]>([]);
  const [projectsList, setProjectsList] = useState<ProjectRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [custModal, setCustModal] = useState(false);
  const [custForm, setCustForm] = useState({
    name: '',
    email: '',
    phone: '',
    companyName: '',
    linkCurrentUser: false,
  });

  const [projModal, setProjModal] = useState(false);
  const [projForm, setProjForm] = useState({
    customerId: '',
    name: '',
    description: '',
    totalContractRupees: '20000',
    advanceRupees: '5000',
    milestoneRupees: '10000',
    finalRupees: '5000',
    includeSchedule: true,
  });
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [cRes, pRes] = await Promise.all([
        apiRequest<{ customers: CustomerRow[] }>('/customers'),
        apiRequest<{ projects: ProjectRow[] }>('/projects'),
      ]);
      setCustomersList(cRes.customers);
      setProjectsList(pRes.projects);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load customers & projects.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await apiRequest<{ customer: { customerRef: string } }>('/customers', {
        method: 'POST',
        body: custForm,
      });
      setNotice(`Customer ${res.customer.customerRef} registered.`);
      setCustModal(false);
      setCustForm({ name: '', email: '', phone: '', companyName: '', linkCurrentUser: false });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create customer.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const totalContractPaise = rupeesInputToPaise(projForm.totalContractRupees);
      const schedule = [];
      if (projForm.includeSchedule) {
        const adv = rupeesInputToPaise(projForm.advanceRupees);
        const mil = rupeesInputToPaise(projForm.milestoneRupees);
        const fin = rupeesInputToPaise(projForm.finalRupees);
        if (adv > 0) schedule.push({ category: 'ADVANCE', title: 'Project Advance Payment', amountDuePaise: adv });
        if (mil > 0) schedule.push({ category: 'MILESTONE', title: 'Milestone Payment', amountDuePaise: mil });
        if (fin > 0) schedule.push({ category: 'FINAL', title: 'Final Delivery Payment', amountDuePaise: fin });
      }
      const res = await apiRequest<{ project: { projectRef: string } }>('/projects', {
        method: 'POST',
        body: {
          customerId: projForm.customerId,
          name: projForm.name,
          description: projForm.description,
          totalContractPaise,
          schedule,
        },
      });
      setNotice(`Project ${res.project.projectRef} created with authorised payment schedule.`);
      setProjModal(false);
      setTab('projects');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create project.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#072146] dark:text-white">
            Customers &amp; Projects
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Admin HQ billing entities with distinct Customer IDs, Project IDs, and authorised instalment schedules.
          </p>
        </div>
        {canCreate && (
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setCustModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#071630] hover:bg-slate-50 dark:hover:bg-[#0a1b38] transition-colors whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Customer</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setProjForm((f) => ({ ...f, customerId: customersList[0]?.id || '' }));
                setProjModal(true);
              }}
              disabled={customersList.length === 0}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white disabled:opacity-40 transition-colors whitespace-nowrap"
            >
              <FolderPlus className="w-3.5 h-3.5" />
              <span>Create Project &amp; Schedule</span>
            </button>
          </div>
        )}
      </div>

      {/* Segmented Control */}
      <div className="inline-flex items-center gap-1 p-1 bg-slate-100 dark:bg-[#0a1b38] border border-slate-200/70 dark:border-slate-800 rounded-xl">
        <button
          type="button"
          onClick={() => setTab('customers')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            tab === 'customers'
              ? 'bg-white dark:bg-[#071630] text-[#0d6efd] dark:text-[#25d0ff] shadow-xs'
              : 'text-slate-500 dark:text-slate-400 hover:text-[#072146] dark:hover:text-white'
          }`}
        >
          Customers ({customersList.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('projects')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            tab === 'projects'
              ? 'bg-white dark:bg-[#071630] text-[#0d6efd] dark:text-[#25d0ff] shadow-xs'
              : 'text-slate-500 dark:text-slate-400 hover:text-[#072146] dark:hover:text-white'
          }`}
        >
          Projects ({projectsList.length})
        </button>
      </div>

      {notice && (
        <div className="border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/20 rounded-lg px-4 py-3 text-xs text-emerald-800 dark:text-emerald-300">
          {notice}
        </div>
      )}
      {error && (
        <div className="border border-red-200 dark:border-red-900 bg-red-50/70 dark:bg-red-950/20 rounded-lg px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {loading ? (
        <SkeletonRows rows={5} />
      ) : tab === 'customers' ? (
        customersList.length === 0 ? (
          <EmptyState
            title="No customers registered yet"
            description="Register your first ForgeX client to assign projects, invoices, and UPI payment requests. Customer IDs (FXC-*) are permanently distinct from Payment IDs (FXPAY-*)."
            action={
              canCreate ? (
                <button
                  type="button"
                  onClick={() => setCustModal(true)}
                  className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
                >
                  Register First Customer
                </button>
              ) : undefined
            }
          />
        ) : (
          <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 bg-slate-50/70 dark:bg-[#0a1b38]/60">
                    <th className="py-2.5 px-4 font-medium">Customer ID</th>
                    <th className="py-2.5 px-4 font-medium">Name · Contact</th>
                    <th className="py-2.5 px-4 font-medium text-right">Projects</th>
                    <th className="py-2.5 px-4 font-medium text-right">Contract Value</th>
                    <th className="py-2.5 px-4 font-medium text-right">Verified Paid</th>
                    <th className="py-2.5 px-4 font-medium text-right">Outstanding</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {customersList.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4 font-mono font-semibold text-slate-900 dark:text-slate-100">
                        {c.customerRef}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900 dark:text-slate-100">
                          {c.name} {c.companyName ? `· ${c.companyName}` : ''}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {c.email} {c.phone ? `· ${c.phone}` : ''}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-right">{c.projectCount}</td>
                      <td className="py-3 px-4 font-mono tabular-nums text-right">
                        {formatInr(c.totalContractPaise)}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-right text-emerald-700 dark:text-emerald-400">
                        {formatInr(c.verifiedPaidPaise)}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-right font-medium">
                        {formatInr(c.outstandingPaise)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      ) : projectsList.length === 0 ? (
        <EmptyState
          title="No projects created yet"
          description="Create a project linked to a customer with an agreed total contract value and Advance / Milestone / Final payment schedule."
        />
      ) : (
        <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 bg-slate-50/70 dark:bg-[#0a1b38]/60">
                  <th className="py-2.5 px-4 font-medium">Project ID</th>
                  <th className="py-2.5 px-4 font-medium">Project · Customer</th>
                  <th className="py-2.5 px-4 font-medium text-right">Contract Value</th>
                  <th className="py-2.5 px-4 font-medium text-right">Verified Paid</th>
                  <th className="py-2.5 px-4 font-medium text-right">Remaining Balance</th>
                  <th className="py-2.5 px-4 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {projectsList.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-mono font-semibold text-slate-900 dark:text-slate-100">
                      {p.projectRef}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 dark:text-slate-100">{p.name}</div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {p.customerName} ({p.customerRef})
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right">
                      {formatInr(p.totalContractPaise)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right text-emerald-700 dark:text-emerald-400">
                      {formatInr(p.verifiedPaidPaise)}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-right font-medium">
                      {formatInr(p.outstandingPaise)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusText status={p.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Customer Modal */}
      <Modal
        open={custModal}
        onClose={() => setCustModal(false)}
        title="Register Customer"
        subtitle="Generates a unique FXC-* Customer ID stored separately from invoices and payment attempts."
      >
        <form onSubmit={handleCreateCustomer} className="space-y-4">
          <div>
            <label className="block text-xs font-medium mb-1">Full Name</label>
            <input
              type="text"
              required
              value={custForm.name}
              onChange={(e) => setCustForm({ ...custForm, name: e.target.value })}
              placeholder="e.g. Satyam Sharma"
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Email</label>
              <input
                type="email"
                required
                value={custForm.email}
                onChange={(e) => setCustForm({ ...custForm, email: e.target.value })}
                placeholder="client@example.com"
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Phone (Optional)</label>
              <input
                type="text"
                value={custForm.phone}
                onChange={(e) => setCustForm({ ...custForm, phone: e.target.value })}
                placeholder="+91 ..."
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Company / Organization (Optional)</label>
            <input
              type="text"
              value={custForm.companyName}
              onChange={(e) => setCustForm({ ...custForm, companyName: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCustModal(false)}
              className="px-4 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
            >
              {submitting ? 'Saving...' : 'Register Customer'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Create Project & Schedule Modal */}
      <Modal
        open={projModal}
        onClose={() => setProjModal(false)}
        title="Create Project & Payment Schedule"
        subtitle="Creates the project, authoritative invoice, and Advance / Milestone / Final payment requests atomically."
      >
        <form onSubmit={handleCreateProject} className="space-y-4">
          <div>
            <label className="block text-xs font-medium mb-1">Customer</label>
            <select
              required
              value={projForm.customerId}
              onChange={(e) => setProjForm({ ...projForm, customerId: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              {customersList.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.customerRef} — {c.name} ({c.email})
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Project Name</label>
              <input
                type="text"
                required
                value={projForm.name}
                onChange={(e) => setProjForm({ ...projForm, name: e.target.value })}
                placeholder="e.g. Website Development"
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Total Contract Value (INR)</label>
              <input
                type="text"
                required
                value={projForm.totalContractRupees}
                onChange={(e) => setProjForm({ ...projForm, totalContractRupees: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
            <input
              type="checkbox"
              checked={projForm.includeSchedule}
              onChange={(e) => setProjForm({ ...projForm, includeSchedule: e.target.checked })}
            />
            <span>Generate invoice and instalment payment schedule immediately</span>
          </label>

          {projForm.includeSchedule && (
            <div className="grid grid-cols-3 gap-3 pt-1">
              <div>
                <label className="block text-xs font-medium mb-1">Advance (₹)</label>
                <input
                  type="text"
                  value={projForm.advanceRupees}
                  onChange={(e) => setProjForm({ ...projForm, advanceRupees: e.target.value })}
                  className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Milestone (₹)</label>
                <input
                  type="text"
                  value={projForm.milestoneRupees}
                  onChange={(e) => setProjForm({ ...projForm, milestoneRupees: e.target.value })}
                  className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Final (₹)</label>
                <input
                  type="text"
                  value={projForm.finalRupees}
                  onChange={(e) => setProjForm({ ...projForm, finalRupees: e.target.value })}
                  className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setProjModal(false)}
              className="px-4 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
            >
              {submitting ? 'Creating...' : 'Create Project'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
