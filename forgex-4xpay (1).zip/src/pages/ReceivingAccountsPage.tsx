import React, { useEffect, useState, useCallback } from 'react';
import { Plus, ShieldAlert, CheckCircle2, Edit3, Power } from 'lucide-react';
import { apiRequest } from '../lib/api.ts';
import { formatUtcDateTime } from '../lib/format.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { EmptyState, Modal, SkeletonRows, StatusText } from '../components/Shell.tsx';

interface ReceivingAccount {
  id: string;
  accountCode: string;
  accountHolderName: string;
  bankName: string;
  accountNumberMasked: string;
  ifsc: string;
  accountType: 'SAVINGS' | 'CURRENT';
  upiId: string;
  displayPayeeName: string;
  internalLabel: string;
  isActive: boolean;
  manualCheckAttested: boolean;
  manualCheckAttestedAt: string | null;
  manualCheckNote: string | null;
  createdAt: string;
  updatedAt: string;
}

interface AuditEntry {
  id: string;
  actorEmail: string;
  action: string;
  resourceId: string;
  createdAt: string;
  status: string;
}

export function ReceivingAccountsPage() {
  const { profile, hasAnyRole, refreshProfile } = useAuth();
  const isSuperAdmin = hasAnyRole('SUPER_ADMIN');
  const [accounts, setAccounts] = useState<ReceivingAccount[]>([]);
  const [history, setHistory] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Create / Edit modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<ReceivingAccount | null>(null);
  const [form, setForm] = useState({
    accountHolderName: '',
    bankName: '',
    accountNumber: '',
    ifsc: '',
    accountType: 'CURRENT' as 'SAVINGS' | 'CURRENT',
    upiId: '',
    displayPayeeName: '',
    internalLabel: '',
    activateImmediately: true,
    mfaCode: '',
    confirmSecurity: false,
  });
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Manual configuration check attestation modal
  const [attestTarget, setAttestTarget] = useState<ReceivingAccount | null>(null);
  const [attestNote, setAttestNote] = useState('');
  const [attestMfa, setAttestMfa] = useState('');

  // Activate modal (with security confirmation)
  const [activateTarget, setActivateTarget] = useState<ReceivingAccount | null>(null);
  const [activateMfa, setActivateMfa] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<{
        accounts: ReceivingAccount[];
        changeHistory: AuditEntry[];
      }>('/admin/receiving-accounts');
      setAccounts(res.accounts);
      setHistory(res.changeHistory);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load receiving accounts.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setFormError(null);
    setForm({
      accountHolderName: '',
      bankName: '',
      accountNumber: '',
      ifsc: '',
      accountType: 'CURRENT',
      upiId: '',
      displayPayeeName: '',
      internalLabel: '',
      activateImmediately: accounts.length === 0,
      mfaCode: '',
      confirmSecurity: false,
    });
    setModalOpen(true);
  };

  const openEdit = (acc: ReceivingAccount) => {
    setEditing(acc);
    setFormError(null);
    setForm({
      accountHolderName: acc.accountHolderName,
      bankName: acc.bankName,
      accountNumber: '',
      ifsc: acc.ifsc,
      accountType: acc.accountType,
      upiId: acc.upiId,
      displayPayeeName: acc.displayPayeeName,
      internalLabel: acc.internalLabel,
      activateImmediately: acc.isActive,
      mfaCode: '',
      confirmSecurity: false,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!profile?.mfaEnabled && !form.confirmSecurity) {
      setFormError('Check the security confirmation box before saving bank details.');
      return;
    }
    setSaving(true);
    try {
      const headers: Record<string, string> = {};
      if (profile?.mfaEnabled) {
        headers['X-MFA-Code'] = form.mfaCode.trim();
      } else {
        headers['X-Security-Confirm'] = 'CONFIRM_BANK_CHANGE';
      }

      if (editing) {
        const payload: Record<string, unknown> = {
          accountHolderName: form.accountHolderName,
          bankName: form.bankName,
          ifsc: form.ifsc.toUpperCase(),
          accountType: form.accountType,
          upiId: form.upiId,
          displayPayeeName: form.displayPayeeName,
          internalLabel: form.internalLabel,
        };
        if (form.accountNumber.trim()) {
          payload.accountNumber = form.accountNumber.trim();
        }
        await apiRequest(`/admin/receiving-accounts/${editing.id}`, {
          method: 'PATCH',
          body: payload,
          headers,
        });
        setNotice(`Receiving account ${editing.accountCode} updated and audited.`);
      } else {
        await apiRequest('/admin/receiving-accounts', {
          method: 'POST',
          body: {
            accountHolderName: form.accountHolderName,
            bankName: form.bankName,
            accountNumber: form.accountNumber.trim(),
            ifsc: form.ifsc.toUpperCase(),
            accountType: form.accountType,
            upiId: form.upiId,
            displayPayeeName: form.displayPayeeName,
            internalLabel: form.internalLabel,
            activateImmediately: form.activateImmediately,
          },
          headers,
        });
        setNotice('Receiving account encrypted (AES-256-GCM) and saved.');
      }
      setModalOpen(false);
      await load();
      await refreshProfile();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to save receiving account.');
    } finally {
      setSaving(false);
    }
  };

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activateTarget) return;
    setSaving(true);
    setFormError(null);
    try {
      const headers: Record<string, string> = profile?.mfaEnabled
        ? { 'X-MFA-Code': activateMfa.trim() }
        : { 'X-Security-Confirm': 'CONFIRM_BANK_CHANGE' };
      await apiRequest(`/admin/receiving-accounts/${activateTarget.id}/activate`, {
        method: 'POST',
        headers,
      });
      setNotice(`Active receiving UPI switched to ${activateTarget.upiId}.`);
      setActivateTarget(null);
      setActivateMfa('');
      await load();
      await refreshProfile();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Activation failed.');
    } finally {
      setSaving(false);
    }
  };

  const handleAttest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!attestTarget) return;
    setSaving(true);
    setFormError(null);
    try {
      const headers: Record<string, string> = profile?.mfaEnabled
        ? { 'X-MFA-Code': attestMfa.trim() }
        : { 'X-Security-Confirm': 'CONFIRM_BANK_CHANGE' };
      await apiRequest(`/admin/receiving-accounts/${attestTarget.id}/attest`, {
        method: 'POST',
        body: { note: attestNote },
        headers,
      });
      setNotice(`Manual configuration check attested for ${attestTarget.accountCode}.`);
      setAttestTarget(null);
      setAttestNote('');
      setAttestMfa('');
      await load();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Attestation failed.');
    } finally {
      setSaving(false);
    }
  };

  const activeAcc = accounts.find((a) => a.isActive) || null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#072146] dark:text-white">
            Receiving Bank Accounts
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Configure the authorised receiving UPI address and bank account used to generate customer payment URIs and QR codes.
          </p>
        </div>
        {isSuperAdmin && (
          <button
            type="button"
            onClick={openCreate}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Receiving Account</span>
          </button>
        )}
      </div>

      {/* Explicit Limitation & Security Disclosure */}
      <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl p-4 shadow-xs flex items-start gap-3">
        <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          <span className="font-semibold text-[#072146] dark:text-white">
            Important Verification Boundary:
          </span>{' '}
          Saving an account number and UPI ID encrypts the account number at rest (AES-256-GCM) and masks it in all views, but does <span className="font-medium">not</span> establish live bank API connectivity or automatic ownership verification. Never enter net-banking passwords, UPI PINs, or OTPs. Use the manual configuration check after verifying details inside your banking app.
        </div>
      </div>

      {notice && (
        <div className="border border-emerald-200 dark:border-emerald-900/70 bg-emerald-50/70 dark:bg-emerald-950/20 rounded-lg px-4 py-3 text-xs text-emerald-800 dark:text-emerald-300">
          {notice}
        </div>
      )}
      {error && (
        <div className="border border-red-200 dark:border-red-900/70 bg-red-50/70 dark:bg-red-950/20 rounded-lg px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {loading ? (
        <SkeletonRows rows={4} />
      ) : accounts.length === 0 ? (
        <EmptyState
          title="No receiving bank account configured"
          description="ForgeX 4XPay starts in an empty configuration state with zero hardcoded or fictional bank data. Register your authorised business bank account and receiving UPI ID to enable customer UPI payment generation."
          action={
            isSuperAdmin ? (
              <button
                type="button"
                onClick={openCreate}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Register First Receiving Account</span>
              </button>
            ) : undefined
          }
        />
      ) : (
        <>
          {/* Active Receiving Account Spotlight */}
          {activeAcc && (
            <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl p-6 shadow-xs">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-mono font-semibold text-slate-500 dark:text-slate-400">
                      {activeAcc.accountCode}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                      Active Receiving Account
                    </span>
                    {activeAcc.internalLabel && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-600 dark:text-slate-300">
                          {activeAcc.internalLabel}
                        </span>
                      </>
                    )}
                  </div>
                  <h2 className="mt-1.5 text-lg font-bold text-[#072146] dark:text-white">
                    {activeAcc.displayPayeeName}
                  </h2>
                  <div className="mt-1 font-mono font-semibold text-sm text-[#0d6efd] dark:text-[#25d0ff]">
                    {activeAcc.upiId}
                  </div>
                </div>

                {isSuperAdmin && (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setAttestTarget(activeAcc);
                        setAttestNote(activeAcc.manualCheckNote || '');
                        setFormError(null);
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>
                        {activeAcc.manualCheckAttested
                          ? 'Update Manual Check'
                          : 'Attest Manual Check'}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => openEdit(activeAcc)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                <div>
                  <div className="text-slate-500 dark:text-slate-400">Account Holder</div>
                  <div className="mt-0.5 font-medium text-slate-900 dark:text-slate-100">
                    {activeAcc.accountHolderName}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 dark:text-slate-400">Bank & Type</div>
                  <div className="mt-0.5 font-medium text-slate-900 dark:text-slate-100">
                    {activeAcc.bankName} · {activeAcc.accountType}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 dark:text-slate-400">Account Number (Masked)</div>
                  <div className="mt-0.5 font-mono font-medium text-slate-900 dark:text-slate-100">
                    {activeAcc.accountNumberMasked}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 dark:text-slate-400">IFSC Code</div>
                  <div className="mt-0.5 font-mono font-medium text-slate-900 dark:text-slate-100">
                    {activeAcc.ifsc}
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                <div>
                  Manual Configuration Check:{' '}
                  {activeAcc.manualCheckAttested ? (
                    <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                      Attested on {formatUtcDateTime(activeAcc.manualCheckAttestedAt)} — “
                      {activeAcc.manualCheckNote}” (Manual check, not bank API)
                    </span>
                  ) : (
                    <span className="text-amber-700 dark:text-amber-400 font-medium">
                      Not yet attested via banking app
                    </span>
                  )}
                </div>
                <span className="font-mono tabular-nums">
                  Updated {formatUtcDateTime(activeAcc.updatedAt)}
                </span>
              </div>
            </div>
          )}

          {/* All Registered Accounts Table */}
          <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800">
              <h2 className="text-sm font-bold text-[#072146] dark:text-white">
                All Registered Receiving Accounts ({accounts.length})
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 bg-slate-50/70 dark:bg-[#0a1b38]/60">
                    <th className="py-2.5 px-4 font-medium">Code</th>
                    <th className="py-2.5 px-4 font-medium">Bank · Account</th>
                    <th className="py-2.5 px-4 font-medium">UPI ID · Payee</th>
                    <th className="py-2.5 px-4 font-medium">Manual Check</th>
                    <th className="py-2.5 px-4 font-medium">Status</th>
                    {isSuperAdmin && <th className="py-2.5 px-4 font-medium text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {accounts.map((acc) => (
                    <tr key={acc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4 font-mono font-medium">{acc.accountCode}</td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900 dark:text-slate-100">
                          {acc.bankName} ({acc.accountType})
                        </div>
                        <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                          {acc.accountNumberMasked} · {acc.ifsc}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-mono text-slate-900 dark:text-slate-100">{acc.upiId}</div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {acc.displayPayeeName}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {acc.manualCheckAttested ? (
                          <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                            Manual Check Done
                          </span>
                        ) : (
                          <span className="text-slate-500 dark:text-slate-400">Unchecked</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <StatusText status={acc.isActive ? 'ACTIVE' : 'INACTIVE'} />
                      </td>
                      {isSuperAdmin && (
                        <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                          {!acc.isActive && (
                            <button
                              type="button"
                              onClick={() => {
                                setActivateTarget(acc);
                                setActivateMfa('');
                                setFormError(null);
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                            >
                              <Power className="w-3 h-3" />
                              <span>Set Active</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => openEdit(acc)}
                            className="px-2.5 py-1 text-xs font-medium rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                          >
                            Edit
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* Account Change Audit History */}
      <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-sm font-bold text-[#072146] dark:text-white">
            Account Change History
          </h2>
        </div>
        {history.length === 0 ? (
          <p className="px-5 py-6 text-xs text-slate-500 dark:text-slate-400">
            No receiving account configuration events recorded yet.
          </p>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {history.map((h) => (
              <div
                key={h.id}
                className="px-5 py-3 flex flex-wrap items-center justify-between gap-2 text-xs"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono font-medium text-slate-900 dark:text-slate-100">
                    {h.action}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-600 dark:text-slate-400">{h.resourceId}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-slate-500 dark:text-slate-400">{h.actorEmail}</span>
                </div>
                <span className="font-mono tabular-nums text-slate-500 dark:text-slate-400">
                  {formatUtcDateTime(h.createdAt)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add / Edit Receiving Account Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? `Edit Receiving Account (${editing.accountCode})` : 'Register Receiving Account'}
        subtitle="Account numbers are encrypted server-side using AES-256-GCM and never exposed to customer endpoints."
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="border border-red-200 dark:border-red-900/60 bg-red-50/70 dark:bg-red-950/30 rounded-md p-3 text-xs text-red-700 dark:text-red-300">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Account Holder Name
              </label>
              <input
                type="text"
                required
                value={form.accountHolderName}
                onChange={(e) => setForm({ ...form, accountHolderName: e.target.value })}
                placeholder="Legal business or proprietor name"
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Bank Name
              </label>
              <input
                type="text"
                required
                value={form.bankName}
                onChange={(e) => setForm({ ...form, bankName: e.target.value })}
                placeholder="e.g. HDFC Bank, ICICI Bank, SBI"
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Account Number {editing ? '(leave blank to keep encrypted value)' : ''}
              </label>
              <input
                type="password"
                required={!editing}
                value={form.accountNumber}
                onChange={(e) => setForm({ ...form, accountNumber: e.target.value })}
                placeholder="9–18 digits"
                className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                IFSC Code
              </label>
              <input
                type="text"
                required
                value={form.ifsc}
                onChange={(e) => setForm({ ...form, ifsc: e.target.value.toUpperCase() })}
                placeholder="e.g. HDFC0001234"
                className="w-full px-3 py-2 text-sm font-mono uppercase rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Account Type
              </label>
              <select
                value={form.accountType}
                onChange={(e) =>
                  setForm({ ...form, accountType: e.target.value as 'SAVINGS' | 'CURRENT' })
                }
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              >
                <option value="CURRENT">Current Account</option>
                <option value="SAVINGS">Savings Account</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Receiving UPI ID (VPA)
              </label>
              <input
                type="text"
                required
                value={form.upiId}
                onChange={(e) => setForm({ ...form, upiId: e.target.value })}
                placeholder="e.g. forgex@hdfcbank"
                className="w-full px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Display Payee Name (UPI `pn`)
              </label>
              <input
                type="text"
                required
                value={form.displayPayeeName}
                onChange={(e) => setForm({ ...form, displayPayeeName: e.target.value })}
                placeholder="Shown in customer UPI app"
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Internal Label (Optional)
              </label>
              <input
                type="text"
                value={form.internalLabel}
                onChange={(e) => setForm({ ...form, internalLabel: e.target.value })}
                placeholder="e.g. Primary Collection Account"
                className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {!editing && (
            <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={form.activateImmediately}
                onChange={(e) => setForm({ ...form, activateImmediately: e.target.checked })}
              />
              <span>Activate immediately as the sole active UPI receiving account</span>
            </label>
          )}

          {/* Security Confirmation / MFA Gate */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
            {profile?.mfaEnabled ? (
              <div>
                <label className="block text-xs font-semibold text-slate-900 dark:text-slate-100 mb-1">
                  6-Digit MFA Authenticator Code (Required)
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={form.mfaCode}
                  onChange={(e) => setForm({ ...form, mfaCode: e.target.value })}
                  placeholder="000000"
                  className="w-40 px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
            ) : (
              <label className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                <input
                  type="checkbox"
                  checked={form.confirmSecurity}
                  onChange={(e) => setForm({ ...form, confirmSecurity: e.target.checked })}
                  className="mt-0.5"
                />
                <span>
                  I confirm I am an authorised Super Admin modifying ForgeX receiving bank details, and this change will be permanently audited.
                </span>
              </label>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-semibold rounded-xl bg-[#072146] hover:bg-[#0b3166] dark:bg-[#0d6efd] dark:hover:bg-[#0b5ed7] text-white disabled:opacity-50 transition-colors"
            >
              {saving ? 'Encrypting & Saving...' : editing ? 'Save Changes' : 'Register Account'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Activate Modal */}
      <Modal
        open={Boolean(activateTarget)}
        onClose={() => setActivateTarget(null)}
        title="Switch Active Receiving UPI Account"
        subtitle="All newly initiated customer UPI requests will route to this receiving address. Past attempts retain their original UPI snapshot."
      >
        <form onSubmit={handleActivate} className="space-y-4">
          {formError && <p className="text-xs text-red-600 dark:text-red-400">{formError}</p>}
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Activate <span className="font-mono font-semibold">{activateTarget?.upiId}</span> (
            {activateTarget?.bankName} {activateTarget?.accountNumberMasked})?
          </p>
          {profile?.mfaEnabled && (
            <div>
              <label className="block text-xs font-medium mb-1">6-Digit MFA Code</label>
              <input
                type="text"
                required
                maxLength={6}
                value={activateMfa}
                onChange={(e) => setActivateMfa(e.target.value)}
                className="w-40 px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          )}
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setActivateTarget(null)}
              className="px-4 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
            >
              Confirm Activation
            </button>
          </div>
        </form>
      </Modal>

      {/* Manual Configuration Check Attestation Modal */}
      <Modal
        open={Boolean(attestTarget)}
        onClose={() => setAttestTarget(null)}
        title="Manual Configuration Check Attestation"
        subtitle="This records that you verified the UPI ID and bank details directly inside your banking application. It is NOT an automated bank API verification."
      >
        <form onSubmit={handleAttest} className="space-y-4">
          {formError && <p className="text-xs text-red-600 dark:text-red-400">{formError}</p>}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Attestation Note
            </label>
            <textarea
              required
              rows={3}
              value={attestNote}
              onChange={(e) => setAttestNote(e.target.value)}
              placeholder="e.g. Sent ₹1 test transfer via BHIM and confirmed credit in HDFC Corporate Banking app."
              className="w-full px-3 py-2 text-sm rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
          </div>
          {profile?.mfaEnabled && (
            <div>
              <label className="block text-xs font-medium mb-1">6-Digit MFA Code</label>
              <input
                type="text"
                required
                maxLength={6}
                value={attestMfa}
                onChange={(e) => setAttestMfa(e.target.value)}
                className="w-40 px-3 py-2 text-sm font-mono rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
          )}
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setAttestTarget(null)}
              className="px-4 py-2 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950"
            >
              Record Manual Attestation
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
