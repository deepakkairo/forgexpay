import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { ThemeProvider } from './context/ThemeContext.tsx';
import { ToastProvider } from './context/ToastContext.tsx';
import { Shell, NavSection, NAV_ITEMS } from './components/Shell.tsx';
import { AuthPortal } from './components/AuthPortal.tsx';
import { BrandLogo } from './components/BrandLogo.tsx';
import { OverviewPage } from './pages/OverviewPage.tsx';
import { ReceivingAccountsPage } from './pages/ReceivingAccountsPage.tsx';
import { CustomersProjectsPage } from './pages/CustomersProjectsPage.tsx';
import {
  PaymentRequestsPage,
  TransactionsPage,
} from './pages/PaymentRequestsTransactionsPage.tsx';
import { VerificationQueuePage } from './pages/VerificationQueuePage.tsx';
import {
  InvoicesPage,
  ReceiptsPage,
  DisputesPage,
} from './pages/InvoicesReceiptsDisputesPage.tsx';
import {
  ConnectedAppsAndApiPage,
  AuditLogsPage,
  SecuritySettingsPage,
  SystemHealthPage,
} from './pages/ApplicationsApiAuditPage.tsx';
import {
  ClientPortalPage,
  EmployeeHqPage,
} from './pages/ClientEmployeePortalsPage.tsx';

function AuthenticatedWorkspace() {
  const { profile, loading } = useAuth();
  const [section, setSection] = useState<NavSection>('overview');

  useEffect(() => {
    if (!profile) return;
    const allowed = NAV_ITEMS.filter((i) => i.roles.some((r) => profile.roles.includes(r)));
    if (allowed.length > 0 && !allowed.some((i) => i.id === section)) {
      setSection(allowed[0].id);
    }
  }, [profile, section]);

  if (loading) {
    return (
      <div className="auth-backdrop min-h-screen flex flex-col items-center justify-center gap-4 px-4">
        <BrandLogo size="md" />
        <div className="text-xs font-mono text-slate-500 dark:text-slate-400">
          Loading forgeXPay session...
        </div>
      </div>
    );
  }

  if (!profile) {
    return <AuthPortal />;
  }

  const renderPage = () => {
    switch (section) {
      case 'overview':
        return <OverviewPage onNavigate={setSection} />;
      case 'transactions':
        return <TransactionsPage />;
      case 'payment-requests':
        return <PaymentRequestsPage />;
      case 'pending-verification':
        return <VerificationQueuePage />;
      case 'receiving-accounts':
        return <ReceivingAccountsPage />;
      case 'customers':
        return <CustomersProjectsPage />;
      case 'invoices':
        return <InvoicesPage />;
      case 'receipts':
        return <ReceiptsPage />;
      case 'disputes':
        return <DisputesPage />;
      case 'connected-apps':
        return <ConnectedAppsAndApiPage mode="apps" />;
      case 'api-credentials':
        return <ConnectedAppsAndApiPage mode="credentials" />;
      case 'audit-logs':
        return <AuditLogsPage />;
      case 'security-settings':
        return <SecuritySettingsPage />;
      case 'system-health':
        return <SystemHealthPage />;
      case 'client-portal':
        return <ClientPortalPage />;
      case 'employee-hq':
        return <EmployeeHqPage />;
      default:
        return <OverviewPage onNavigate={setSection} />;
    }
  };

  return (
    <Shell active={section} onNavigate={setSection}>
      {renderPage()}
    </Shell>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <AuthenticatedWorkspace />
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}
