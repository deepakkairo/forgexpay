import React, { useState, useEffect, useRef } from 'react';
import {
  LayoutDashboard,
  ArrowLeftRight,
  FileSpreadsheet,
  ShieldCheck,
  Landmark,
  Users,
  FileText,
  Receipt,
  AlertTriangle,
  Blocks,
  KeyRound,
  ScrollText,
  Lock,
  Activity,
  Briefcase,
  Smartphone,
  Bell,
  Sun,
  Moon,
  LogOut,
  Menu,
  X,
  ChevronDown,
  Settings,
} from 'lucide-react';
import { useAuth, RoleCode } from '../context/AuthContext.tsx';
import { useTheme } from '../context/ThemeContext.tsx';
import { useToast } from '../context/ToastContext.tsx';
import { apiRequest } from '../lib/api.ts';
import { formatUtcDateTime, statusColorClass, humanizeStatus } from '../lib/format.ts';
import { BrandLogo } from './BrandLogo.tsx';

export type NavSection =
  | 'overview'
  | 'transactions'
  | 'payment-requests'
  | 'pending-verification'
  | 'receiving-accounts'
  | 'customers'
  | 'invoices'
  | 'receipts'
  | 'disputes'
  | 'connected-apps'
  | 'api-credentials'
  | 'audit-logs'
  | 'security-settings'
  | 'system-health'
  | 'client-portal'
  | 'employee-hq';

interface NavItem {
  id: NavSection;
  label: string;
  breadcrumb: string;
  icon: React.ComponentType<{ className?: string }>;
  group: 'Operations' | 'Configuration' | 'Governance' | 'Ecosystem Portals';
  roles: RoleCode[];
}

export const NAV_ITEMS: NavItem[] = [
  {
    id: 'overview',
    label: 'Overview',
    breadcrumb: 'Dashboard / Overview',
    icon: LayoutDashboard,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'transactions',
    label: 'Transactions',
    breadcrumb: 'Operations / Transactions',
    icon: ArrowLeftRight,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'payment-requests',
    label: 'Payment Requests',
    breadcrumb: 'Operations / Payment Requests',
    icon: FileSpreadsheet,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'pending-verification',
    label: 'Pending Verification',
    breadcrumb: 'Finance HQ / Pending Verification & Reconciliation',
    icon: ShieldCheck,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN'],
  },
  {
    id: 'customers',
    label: 'Customers',
    breadcrumb: 'Billing / Customers & Projects',
    icon: Users,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'invoices',
    label: 'Invoices',
    breadcrumb: 'Billing / Invoices',
    icon: FileText,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'receipts',
    label: 'Receipts',
    breadcrumb: 'Billing / Verified Receipts',
    icon: Receipt,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'disputes',
    label: 'Missing Payments',
    breadcrumb: 'Support / Missing Payments & Disputes',
    icon: AlertTriangle,
    group: 'Operations',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ'],
  },
  {
    id: 'receiving-accounts',
    label: 'Receiving Accounts',
    breadcrumb: 'Settings / Payment Configuration / Receiving Accounts',
    icon: Landmark,
    group: 'Configuration',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN'],
  },
  {
    id: 'connected-apps',
    label: 'Connected Apps',
    breadcrumb: 'Platform / Connected Applications',
    icon: Blocks,
    group: 'Configuration',
    roles: ['SUPER_ADMIN'],
  },
  {
    id: 'api-credentials',
    label: 'API Credentials',
    breadcrumb: 'Platform / API Credentials',
    icon: KeyRound,
    group: 'Configuration',
    roles: ['SUPER_ADMIN'],
  },
  {
    id: 'audit-logs',
    label: 'Audit Logs',
    breadcrumb: 'Governance / Audit Logs',
    icon: ScrollText,
    group: 'Governance',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN'],
  },
  {
    id: 'security-settings',
    label: 'Security Settings',
    breadcrumb: 'Governance / Security & Tax Settings',
    icon: Lock,
    group: 'Governance',
    roles: ['SUPER_ADMIN'],
  },
  {
    id: 'system-health',
    label: 'System Health',
    breadcrumb: 'Governance / System Health',
    icon: Activity,
    group: 'Governance',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN'],
  },
  {
    id: 'client-portal',
    label: 'Client App Portal',
    breadcrumb: 'ForgeX Ecosystem / Client Payment Portal',
    icon: Smartphone,
    group: 'Ecosystem Portals',
    roles: ['SUPER_ADMIN', 'FINANCE_ADMIN', 'ADMIN_HQ', 'CLIENT'],
  },
  {
    id: 'employee-hq',
    label: 'Employee HQ',
    breadcrumb: 'ForgeX Ecosystem / Employee HQ (Restricted)',
    icon: Briefcase,
    group: 'Ecosystem Portals',
    roles: ['SUPER_ADMIN', 'ADMIN_HQ', 'EMPLOYEE'],
  },
];

interface NotificationItem {
  id: string;
  eventType: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export function StatusText({ status }: { status: string }) {
  return (
    <span className={`font-semibold text-xs tracking-tight whitespace-nowrap ${statusColorClass(status)}`}>
      {humanizeStatus(status)}
    </span>
  );
}

export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl p-10 text-center shadow-xs">
      <h3 className="text-base font-bold text-[#072146] dark:text-white">{title}</h3>
      <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 max-w-lg mx-auto leading-relaxed">
        {description}
      </p>
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}

export function SkeletonRows({ rows = 5 }: { rows?: number }) {
  return (
    <div className="border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-[#071630] rounded-2xl divide-y divide-slate-100 dark:divide-slate-800/80 shadow-xs">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="px-5 py-4 flex items-center justify-between gap-4 animate-pulse">
          <div className="h-3.5 w-36 bg-slate-200/80 dark:bg-slate-800 rounded-md" />
          <div className="h-3.5 w-48 bg-slate-100 dark:bg-slate-800/70 rounded-md" />
          <div className="h-3.5 w-24 bg-slate-200/80 dark:bg-slate-800 rounded-md" />
        </div>
      ))}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  maxWidth = 'max-w-xl',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidth?: string;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div
        className={`w-full ${maxWidth} bg-white dark:bg-[#071630] border border-slate-200/90 dark:border-slate-800 rounded-2xl shadow-2xl my-8 fade-view overflow-hidden`}
      >
        <div className="flex items-start justify-between gap-4 px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-base font-bold text-[#072146] dark:text-white">{title}</h2>
            {subtitle && (
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                {subtitle}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="p-1.5 rounded-xl text-slate-400 hover:text-[#072146] dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-6 max-h-[78vh] overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

export function Shell({
  active,
  onNavigate,
  children,
}: {
  active: NavSection;
  onNavigate: (section: NavSection) => void;
  children: React.ReactNode;
}) {
  const { profile, unreadNotifications, logout, refreshProfile, hasAnyRole } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { showToast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifList, setNotifList] = useState<NotificationItem[]>([]);
  const [notifLoading, setNotifLoading] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const profileMenuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(e.target as Node)) {
        setProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const visibleItems = NAV_ITEMS.filter((item) =>
    profile ? item.roles.some((r) => profile.roles.includes(r)) : false
  );
  const currentItem = visibleItems.find((i) => i.id === active) || visibleItems[0];
  const groups: Array<NavItem['group']> = [
    'Operations',
    'Configuration',
    'Governance',
    'Ecosystem Portals',
  ];

  const initials = (profile?.displayName || profile?.email || 'FX')
    .split(/[\s@._-]+/)
    .filter(Boolean)
    .map((w) => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const openNotifications = async () => {
    setNotifOpen(true);
    setNotifLoading(true);
    try {
      const data = await apiRequest<{ notifications: NotificationItem[] }>('/notifications');
      setNotifList(data.notifications);
    } catch {
      // handled silently
    } finally {
      setNotifLoading(false);
    }
  };

  const markAllRead = async () => {
    await apiRequest('/notifications/read-all', { method: 'POST' });
    setNotifList((prev) => prev.map((n) => ({ ...n, isRead: true })));
    await refreshProfile();
    showToast('All notifications marked as read.', 'info');
  };

  const handleToggleTheme = () => {
    toggleTheme();
    showToast(`Switched to ${theme === 'dark' ? 'Light' : 'Dark'} mode`, 'info');
  };

  const handleSignOut = async () => {
    setProfileMenuOpen(false);
    await logout();
    showToast('Signed out cleanly.', 'info');
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white dark:bg-[#071630] border-r border-slate-200/90 dark:border-slate-800">
      <div className="h-16 px-5 flex items-center justify-between border-b border-slate-100 dark:border-slate-800 shrink-0">
        <button
          type="button"
          onClick={() => {
            onNavigate(visibleItems[0]?.id || 'overview');
            setMobileMenuOpen(false);
          }}
          className="focus:outline-none rounded-lg"
          aria-label="forgeXPay Home"
        >
          <BrandLogo size="md" />
        </button>
        <button
          type="button"
          onClick={() => setMobileMenuOpen(false)}
          className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-[#072146] dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
          aria-label="Close navigation"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5" aria-label="Primary navigation">
        {groups.map((group) => {
          const items = visibleItems.filter((i) => i.group === group);
          if (items.length === 0) return null;
          return (
            <div key={group}>
              <div className="px-3 mb-1.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500 tracking-wide">
                {group}
              </div>
              <div className="space-y-0.5">
                {items.map((item) => {
                  const Icon = item.icon;
                  const isActive = item.id === active;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        onNavigate(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors whitespace-nowrap ${
                        isActive
                          ? 'bg-sky-50 dark:bg-sky-500/15 text-[#0d6efd] dark:text-[#25d0ff] font-semibold'
                          : 'text-slate-600 dark:text-slate-400 font-medium hover:bg-slate-100/80 dark:hover:bg-slate-800/70 hover:text-[#072146] dark:hover:text-white'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-100 dark:border-slate-800 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#072146] via-[#0d6efd] to-[#00b8ff] text-white font-bold text-xs flex items-center justify-center shrink-0">
            {initials}
          </div>
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#072146] dark:text-white truncate">
              {profile?.displayName}
            </div>
            <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
              {profile?.roles.join(' · ')}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-[#f8fafc] dark:bg-[#040e21] text-[#072146] dark:text-slate-100">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 sticky top-0 h-screen">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="w-64 h-full">{sidebarContent}</div>
          <div
            className="flex-1 bg-slate-950/50 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
        </div>
      )}

      {/* Main Column */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 sticky top-0 z-30 bg-white/90 dark:bg-[#071630]/90 backdrop-blur-md border-b border-slate-200/90 dark:border-slate-800 px-4 lg:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation"
              className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="lg:hidden">
              <BrandLogo size="sm" />
            </div>
            <span className="hidden sm:inline text-sm font-medium text-slate-500 dark:text-slate-400 truncate">
              {currentItem?.breadcrumb || 'forgeXPay'}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={openNotifications}
              className="inline-flex items-center gap-1.5 px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
              aria-label="Open notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifications > 0 && (
                <span className="font-mono tabular-nums font-bold text-[#0d6efd] dark:text-[#25d0ff]">
                  {unreadNotifications}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={handleToggleTheme}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors shrink-0"
              aria-label="Toggle color theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* User Profile Dropdown */}
            <div className="relative" ref={profileMenuRef}>
              <button
                type="button"
                onClick={() => setProfileMenuOpen((o) => !o)}
                className="flex items-center gap-2 p-1 pr-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0a1b38] hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#072146] via-[#0d6efd] to-[#00b8ff] text-white font-bold text-[11px] flex items-center justify-center">
                  {initials}
                </div>
                <span className="hidden sm:inline text-xs font-semibold text-[#072146] dark:text-white max-w-[120px] truncate">
                  {profile?.displayName}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {profileMenuOpen && (
                <div className="absolute right-0 mt-2 w-60 rounded-2xl bg-white dark:bg-[#071630] border border-slate-200 dark:border-slate-800 shadow-lg py-2 z-50 fade-view">
                  <div className="px-4 py-2.5 border-b border-slate-100 dark:border-slate-800">
                    <p className="text-xs font-bold text-[#072146] dark:text-white truncate">
                      {profile?.displayName}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {profile?.email}
                    </p>
                    <p className="mt-1 text-[10px] font-mono text-slate-400 truncate">
                      {profile?.roles.join(' · ')}
                    </p>
                  </div>
                  {hasAnyRole('SUPER_ADMIN') && (
                    <>
                      <button
                        type="button"
                        onClick={() => {
                          onNavigate('security-settings');
                          setProfileMenuOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 transition-colors"
                      >
                        <Settings className="w-3.5 h-3.5" />
                        <span>Security &amp; Tax Settings</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onNavigate('api-credentials');
                          setProfileMenuOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 transition-colors"
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        <span>API Credentials</span>
                      </button>
                    </>
                  )}
                  <div className="my-1 border-t border-slate-100 dark:border-slate-800" />
                  <button
                    type="button"
                    onClick={handleSignOut}
                    className="w-full px-4 py-2 text-left text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-2 transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 lg:py-8 max-w-[1440px] w-full mx-auto fade-view">
          {children}
        </main>
      </div>

      {/* Notifications Modal */}
      <Modal
        open={notifOpen}
        onClose={() => setNotifOpen(false)}
        title="Internal Notifications"
        subtitle="Event-driven alerts across forgeXPay. Notification delivery never alters verified financial truth."
      >
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {notifList.length} recent events
          </span>
          {notifList.some((n) => !n.isRead) && (
            <button
              type="button"
              onClick={markAllRead}
              className="text-xs font-semibold text-[#0d6efd] dark:text-[#25d0ff] hover:underline"
            >
              Mark all read
            </button>
          )}
        </div>
        {notifLoading ? (
          <SkeletonRows rows={3} />
        ) : notifList.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400 py-6 text-center">
            No notifications recorded yet.
          </p>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200/90 dark:border-slate-800 rounded-xl overflow-hidden">
            {notifList.map((n) => (
              <div
                key={n.id}
                className={`p-3.5 ${
                  n.isRead ? 'opacity-70' : 'bg-sky-50/40 dark:bg-sky-500/5'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[#072146] dark:text-white">
                    {n.title}
                  </span>
                  <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                    {formatUtcDateTime(n.createdAt)}
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {n.message}
                </p>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
