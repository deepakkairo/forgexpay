import { db } from '../db/index.ts';
import { roles, systemSettings, connectedApplications } from '../db/schema.ts';

const SYSTEM_ROLES = [
  {
    code: 'SUPER_ADMIN',
    name: 'Super Administrator',
    description:
      'Full access to receiving bank accounts, API credentials, RBAC security settings, verification, and audit trails.',
    permissionsJson: ['*'],
  },
  {
    code: 'FINANCE_ADMIN',
    name: 'Finance HQ Administrator',
    description:
      'Manages payment verification queue, CSV bank statement reconciliation, disputes, ledger reports, and receipts.',
    permissionsJson: [
      'verification:read',
      'verification:confirm',
      'reconciliation:manage',
      'disputes:manage',
      'transactions:read',
      'receipts:read',
      'invoices:read',
    ],
  },
  {
    code: 'ADMIN_HQ',
    name: 'Admin HQ Operator',
    description:
      'Creates customers, projects, invoices, and payment requests. Cannot verify bank credits or view bank secrets.',
    permissionsJson: [
      'customers:manage',
      'projects:manage',
      'invoices:manage',
      'payment_requests:manage',
      'transactions:read',
    ],
  },
  {
    code: 'EMPLOYEE',
    name: 'Employee HQ Member',
    description:
      'Restricted read-only visibility into assigned project payment milestones and advance verification status.',
    permissionsJson: ['employee_projects:read'],
  },
  {
    code: 'CLIENT',
    name: 'ForgeX Client',
    description:
      'Client payment portal access strictly scoped to own projects, UPI payment initiation, receipts, and disputes.',
    permissionsJson: ['client_portal:read', 'payments:initiate', 'payments:report', 'disputes:create'],
  },
];

const DEFAULT_APPS = [
  {
    appCode: 'FXAPP-ADMIN-HQ',
    name: 'ForgeX Admin HQ',
    category: 'ADMIN_HQ',
    description: 'Creates client projects, invoices, and agreed payment schedules.',
  },
  {
    appCode: 'FXAPP-FINANCE-HQ',
    name: 'ForgeX Finance HQ',
    category: 'FINANCE_HQ',
    description: 'Operates verification queue, bank statement reconciliation, and ledger accounting.',
  },
  {
    appCode: 'FXAPP-EMPLOYEE-HQ',
    name: 'ForgeX Employee HQ',
    category: 'EMPLOYEE_HQ',
    description: 'Restricted project payment status viewer for assigned engineering and delivery staff.',
  },
  {
    appCode: 'FXAPP-CLIENT-APP',
    name: 'ForgeX Client Application',
    category: 'CLIENT_APP',
    description: 'Customer-facing UPI payment portal, QR checkout, receipt downloads, and missing payment support.',
  },
];

let bootstrapPromise: Promise<void> | null = null;

/**
 * Lazily ensures immutable system roles, default business settings (tax UNCONFIGURED),
 * and ForgeX ecosystem application directory exist.
 * NEVER seeds fictional bank accounts, fake payments, or fabricated tax IDs.
 */
export function ensureSystemBootstrapped(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = (async () => {
      for (const role of SYSTEM_ROLES) {
        await db.insert(roles).values(role).onConflictDoNothing({ target: roles.code });
      }

      for (const app of DEFAULT_APPS) {
        await db
          .insert(connectedApplications)
          .values(app)
          .onConflictDoNothing({ target: connectedApplications.appCode });
      }

      await db
        .insert(systemSettings)
        .values({
          key: 'business_profile',
          valueJson: {
            legalName: process.env.FORGEX_LEGAL_NAME || 'ForgeX',
            address: process.env.FORGEX_ADDRESS || '',
            email: '',
            taxRegime: process.env.FORGEX_TAX_REGIME || 'UNCONFIGURED',
            gstin: process.env.FORGEX_GSTIN || '',
            taxNote:
              'Configure verified legal entity and GST registration details before issuing tax-specific invoices.',
          },
        })
        .onConflictDoNothing({ target: systemSettings.key });

      await db
        .insert(systemSettings)
        .values({
          key: 'payment_policy',
          valueJson: {
            dualApprovalThresholdPaise: Number(process.env.DUAL_APPROVAL_THRESHOLD_PAISE || 5000000),
            qrExpiryMinutes: 30,
            maxDisputesPerAttempt: 2,
          },
        })
        .onConflictDoNothing({ target: systemSettings.key });
    })().catch((err) => {
      bootstrapPromise = null;
      throw err;
    });
  }
  return bootstrapPromise;
}
